WEBSITE PERSONAL - PETUNJUK SINGKAT

File HTML:
- index.html = halaman beranda
- gaming.html = hobi main game
- film.html = hobi nonton film
- kuliah.html = kegiatan kuliah
- keluarga.html = membantu keluarga
- olahraga.html = kegiatan olahraga

Folder:
- css/style.css = semua aturan CSS
- img/ = ilustrasi SVG lokal

Sebelum dikumpulkan:
1. Ganti isi teks sesuai kegiatanmu sendiri jika ada yang ingin disesuaikan.
2. Jika dosen meminta identitas, tambahkan nama dan NPM di halaman beranda.
3. Tes index.html dengan membuka file tersebut di browser.
4. Upload seluruh isi folder ini ke repository GitHub.
